class Test:
    def __init__(self):
        self.a = 1
        self.b = 2
        self.c = 3

    def func1(self, a, b):
        return a + b

    def func2(self, a, b, c):
        return a + b + c


    def func3(self, a, b, c, d):
        return a + b + c + d     