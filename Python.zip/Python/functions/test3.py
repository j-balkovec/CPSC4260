def func1(a, b):
    return a + b

def func2(a, b):
    return a + b 

def func3(a, b, c, d):
    return a + b 

def func4(e, f, g, h):
    return e + f   

def func5(matrix):
    for i in range(len(matrix)):
        for j in range(len(matrix[i])):
            print(matrix[i][j])

def func6(mat):
    for l in range(0,len(mat)):
        for m in range(0,len(mat[l])):
            print(mat[l][m])   